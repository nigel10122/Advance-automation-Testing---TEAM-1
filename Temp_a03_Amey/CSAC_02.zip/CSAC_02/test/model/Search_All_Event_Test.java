package model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

	@RunWith(JUnitParamsRunner.class)
	public class Search_All_Event_Test { 
		
		Event_Date_Time_Coverage event;
		EventErrorMsgs eventerrormsg; 
		
		@Before
		public void setUp() throws Exception {
			event = new Event_Date_Time_Coverage();
			eventerrormsg = new EventErrorMsgs();
		}	

		@Test
		@FileParameters("test/model/SearchAllEvent_Amey.csv")
		public void test(int tc, String eventdate, String starttime,String type, String eventdateError, String starttimeError /*, String errorMsg, String currenttime, String addtime*/ ) {

			Event_Date_Time_Coverage eventmodel= new Event_Date_Time_Coverage(eventdate, starttime, type);
		
			eventmodel.validateSearchAllEvent(eventmodel, eventerrormsg);
			assertTrue(eventdateError.equals(eventerrormsg.getEventdateError()));
			assertTrue(starttimeError.equals(eventerrormsg.getStarttimeError()));
			//assertTrue(errorMsg.equals(eventerrormsg.getErrorMsg()));

		}
	}

	