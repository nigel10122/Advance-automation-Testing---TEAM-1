package model;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;







public class Event_Date_Time_Coverage {
	 String type;
	 String eventdate;
	 String starttime;
	 DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
	 DateFormat timeformat = new SimpleDateFormat("HH:mm:ss");
	 String currentDate = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
	 String currentTime = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
	 
	 


    public Event_Date_Time_Coverage()
    {
    	
    }
    
    public Event_Date_Time_Coverage(String eventdate, String starttime, String type) {
        this.eventdate = eventdate;
        this.starttime = starttime;
        this.type = type;
    }
    



	public String getEventdate() {
		return eventdate;
	}

	
	public String getStarttime() {
		return starttime;
	}

    




	
	public void validateSearchAllEvent (Event_Date_Time_Coverage event, EventErrorMsgs errorMsgs) {
		
		errorMsgs.setEventdateError(validateDate(event.getEventdate()));
		errorMsgs.setStarttimeError(validateDateTime(event.getEventdate(),event.getStarttime()));
		errorMsgs.setErrorMsg();
	}
	
	public Date ConvertedStartTimeLimit()
	{
		
		Date StartTimeLimit = null;
		try {
			StartTimeLimit = timeformat.parse("07:00:00");
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return StartTimeLimit;
	}
	
	public Date ConvertedEndTimeLimit()
	{
		
		Date EndTimeLimit = null;
		try {
			EndTimeLimit = timeformat.parse("22:00:00");
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return EndTimeLimit;
	}
	
	
	
	public Date ConvertedEnteredDate(String Entereddate)
	{
		
		Date EnteredDate = null;
		try {
			EnteredDate = dateformat.parse(Entereddate);
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return EnteredDate;
	}
	
	public Date ConvertedCurrentDate()
	{
		
		String Currentdate = currentDate;
		
		Date CurrentDate = null;
		try {
			CurrentDate = dateformat.parse(Currentdate);
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return CurrentDate;
	}
	
	public Date ConvertedEnteredTime(String Enteredtime)
	{
		
		Date EnteredTime = null;
		try {
			EnteredTime = timeformat.parse(Enteredtime);
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return EnteredTime;
	}
	

	public Date ConvertedCurrentTime()
	{
		
		String Currenttime= currentTime;
		
		Date CurrentTime = null;
		try {
			CurrentTime = timeformat.parse(Currenttime);
		} catch (ParseException e) {
			
			//e.printStackTrace();
		} 
		return CurrentTime;
	}
	

public String validateDate(String Date) 
	{
		String result = "";
		Event event = new Event();

		if(!isDateValid(Date))
		{
			result = "Invalid Date format";
		}
		else
			if(event.ConvertedEnteredDate(Date).before(event.ConvertedCurrentDate()))
			{
				result = "Date cannot be in the past";
			}
			
			
		
		return result;
	}

	
	public String validateDateTime(String Date, String Time)
	{
	
		
		String result = "";
		if(!isDateValid(Date))
		{
			result = "Invalid Date-Time format";
		}
		else 
			if(!isTimeValid(Time))
		{
			result = "Invalid Time format";
		}
		else
			if(ConvertedEnteredDate(Date).before(ConvertedCurrentDate()))
			{
				result = "Time cannot be in the past";
			}
			else
				if(ConvertedEnteredDate(Date).equals(ConvertedCurrentDate()) || ConvertedEnteredDate(Date).after(ConvertedCurrentDate()) )
				if(ConvertedEnteredTime(Time).before(ConvertedStartTimeLimit()) || ConvertedEnteredTime(Time).after(ConvertedEndTimeLimit()))
				{
					result = "Event Timings must be between 7:00 AM(inclusive) and 10:00 PM(inclusive)";
				}
			else
				if(ConvertedEnteredDate(Date).equals(ConvertedCurrentDate())) 
					if( ConvertedEnteredTime(Time).before(ConvertedCurrentTime()))
						{
						result = "Time cannot be in the past";
						}
		
		return result;
	}

	final static String DATE_FORMAT = "MM/dd/yyyy";

	public  boolean isDateValid(String date) 
	{
	        try {
	            DateFormat df = new SimpleDateFormat(DATE_FORMAT);
	            df.setLenient(false);
	            df.parse(date);
	            return true;
	        } catch (ParseException e) {
	            return false;
	        }
	}
	
	final static String TIME_FORMAT = "HH:mm:ss";

	public  boolean isTimeValid(String time) 
	{
	        try {
	            DateFormat df = new SimpleDateFormat(TIME_FORMAT);
	            df.setLenient(false);
	            df.parse(time);
	            return true;
	        } catch (ParseException e) {
	            return false;
	        }
	}


	
	
}
	
	
    



