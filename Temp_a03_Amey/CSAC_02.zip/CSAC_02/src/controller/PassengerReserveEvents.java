package controller;

import java.io.IOException;

import java.lang.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import data.ReservationDAO;

import model.Reservation;

import util.ConnectionPro;


@WebServlet("/PassengerReserveEvents")
public class PassengerReserveEvents extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public PassengerReserveEvents() {
        super();
        
    }
    
    public static int capacity;
   public static boolean proceed;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//HttpSession session = request.getSession();
		//session.removeAttribute("errorMsgs");

		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		session.removeAttribute("errorMsgs");

		String eventname = request.getParameter("eventname");
		String eventdate = request.getParameter("eventdate");
		String starttime = request.getParameter("starttime");
		String duration = request.getParameter("duration");
		String location = request.getParameter("location");
		int numberofattendees = Integer.parseInt(request.getParameter("numberofattendees"));
		capacity = Integer.parseInt(request.getParameter("capacity"));
		String eventcoordinator = request.getParameter("eventcoordinator");
		String type = request.getParameter("type");
		String estattendees = request.getParameter("estattendees");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String number = request.getParameter("number");
		String email = request.getParameter("email");
		HttpSession errorsession = request.getSession();
		
		HttpSession successfullsession = request.getSession();
		String successmessage = "Reservation Succesfull";
		Reservation reservation = new Reservation();
		session.setAttribute("EVENTSA", numberofattendees);

		Reservation reservationModel = new Reservation( eventname, eventdate,  starttime,  duration , location,  numberofattendees,  capacity,  eventcoordinator,  type,estattendees,firstname,lastname,number,email);
		
		//int count = 0;
		//int type_int = Integer.parseInt(reservation.getType());
		
		
		
	//	proceed = reservation.validateAttendes(eventname,eventdate,starttime);
		
		
		
		String reservationerrMsg = reservation.getCountShowTypeModel(type, eventdate, firstname, lastname);
		
		if(!reservationerrMsg.equals("")) 
		{
			if(type.equalsIgnoreCase("Show")) {
				response.sendRedirect("ExceedEventShow.jsp");
				//errorsession.setAttribute("reservationerrMsg",reservationerrMsg);

			}
			else {
			response.sendRedirect("ExceedAthleticEvent.jsp");
			//errorsession.setAttribute("reservationerrMsg",reservationerrMsg);

			}
		}		
else {if(reservationModel.validateAttendes(eventname,eventdate,starttime)){
	try
		{ 
			ReservationDAO reserveevent = new ReservationDAO(ConnectionPro.getConnection());
			if(reserveevent.ReserveEvent(reservationModel))
			{
				response.sendRedirect("passengersuccessmessage.jsp");
				successfullsession.setAttribute("successmessage", successmessage);	
			}
			else {
				response.sendRedirect("exceedEventCapacity.jsp");}
		}catch(Exception e) {
			
			e.printStackTrace();
		}}else {
			response.sendRedirect("exceedEventCapacity.jsp");
		}
}
	
	
	}		}
				
				
				

// 
	
//Reservation.attendes==0
