package exercise_04;

public interface ServerData {
	public double getTotal();
	
	
	
	
}