package util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ConvertDateTime {
	
    private DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
	private DateFormat timeformat = new SimpleDateFormat("HH:mm:ss");
	private String currentDate = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
	private	String currentTime = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
	
	
	public Date ConvertedStartTimeLimit()
	{
		
		Date StartTimeLimit = null;
		try {
			StartTimeLimit = timeformat.parse("07:00:00");
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return StartTimeLimit;
	}
	
	public Date ConvertedEndTimeLimit()
	{
		
		Date EndTimeLimit = null;
		try {
			EndTimeLimit = timeformat.parse("22:00:00");
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return EndTimeLimit;
	}
	
	
	
	public Date ConvertedEnteredDate(String Entereddate)
	{
		
		Date EnteredDate = null;
		try {
			EnteredDate = dateformat.parse(Entereddate);
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return EnteredDate;
	}
	
	public Date ConvertedCurrentDate()
	{
		
		String Currentdate = currentDate;
		
		Date CurrentDate = null;
		try {
			CurrentDate = dateformat.parse(Currentdate);
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return CurrentDate;
	}
	
	public Date ConvertedEnteredTime(String Enteredtime)
	{
		
		Date EnteredTime = null;
		try {
			EnteredTime = timeformat.parse(Enteredtime);
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return EnteredTime;
	}
	

	public Date ConvertedCurrentTime()
	{
		
		String Currenttime= currentTime;
		
		Date CurrentTime = null;
		try {
			CurrentTime = timeformat.parse(Currenttime);
		} catch (ParseException e) {
			
			e.printStackTrace();
		} 
		return CurrentTime;
	}
	
	

}
