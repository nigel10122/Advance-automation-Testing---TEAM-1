package model;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import util.ConvertDateTime;







public class Event_Date_Time_Coverage {
	 String type;
	 String eventdate;
	 String starttime;
	 DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
	 DateFormat timeformat = new SimpleDateFormat("HH:mm:ss");
	 String currentDate = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
	 String currentTime = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
	 
	 ConvertDateTime datetime = new ConvertDateTime();
	 


    public Event_Date_Time_Coverage()
    {
    	
    }
    
    public Event_Date_Time_Coverage(String eventdate, String starttime, String type) {
        this.eventdate = eventdate;
        this.starttime = starttime;
        this.type = type;
    }
    



	public String getEventdate() {
		return eventdate;
	}

	
	public String getStarttime() {
		return starttime;
	}

    




	
	public void validateSearchAllEvent (Event_Date_Time_Coverage event, EventErrorMsgs errorMsgs) {
		
		errorMsgs.setEventdateError(validateDate(event.getEventdate()));
		errorMsgs.setStarttimeError(validateDateTime(event.getEventdate(),event.getStarttime()));
		errorMsgs.setErrorMsg();
	}
	

	

public String validateDate(String Date) 
	{
		String result = "";
		

		if(!isDateValid(Date))
		{
			result = "Invalid Date format";
		}
		else
			if(datetime.ConvertedEnteredDate(Date).before(datetime.ConvertedCurrentDate()))
			{
				result = "Date cannot be in the past";
			}
			
			
		
		return result;
	}

	
	public String validateDateTime(String Date, String Time)
	{
	
		
		String result = "";
		if(!isDateValid(Date))
		{
			result = "Invalid Date-Time format";
		}
		else 
			if(!isTimeValid(Time))
		{
			result = "Invalid Time format";
		}
		else
			if(datetime.ConvertedEnteredDate(Date).before(datetime.ConvertedCurrentDate()))
			{
				result = "Time cannot be in the past";
			}
			else
				//if(!(ConvertedEnteredDate(Date).before(ConvertedCurrentDate())))
				if(datetime.ConvertedEnteredTime(Time).before(datetime.ConvertedStartTimeLimit()) || datetime.ConvertedEnteredTime(Time).after(datetime.ConvertedEndTimeLimit()))
				{
					result = "Event Timings must be between 7:00 AM(inclusive) and 10:00 PM(inclusive)";
				}
			else
				if(datetime.ConvertedEnteredDate(Date).equals(datetime.ConvertedCurrentDate())) 
					if( datetime.ConvertedEnteredTime(Time).before(datetime.ConvertedCurrentTime()))
						{
						result = "Time cannot be in the past";
						}
		
		return result;
	}

	final static String DATE_FORMAT = "MM/dd/yyyy";

	public  boolean isDateValid(String date) 
	{
	        try {
	            DateFormat df = new SimpleDateFormat(DATE_FORMAT);
	            df.setLenient(false);
	            df.parse(date);
	            return true;
	        } catch (ParseException e) {
	            return false;
	        }
	}
	
	final static String TIME_FORMAT = "HH:mm:ss";

	public  boolean isTimeValid(String time) 
	{
	        try {
	            DateFormat df = new SimpleDateFormat(TIME_FORMAT);
	            df.setLenient(false);
	            df.parse(time);
	            return true;
	        } catch (ParseException e) {
	            return false;
	        }
	}


	
	
}
	
	
    



